#ifndef __LINUX_CONFIG_H__
#define __LINUX_CONFIG_H__

#define GFP_KERNEL 0

/* #define CONFIG_JFFS2_FS_WRITEBUFFER 0 */
/* #define CONFIG_JFFS2_PROC  */
/* #define CONFIG_JFFS2_RTIME */
/* #define CONFIG_JFFS2_RUBIN */
/* #define CONFIG_JFFS2_ZLIB  */

#endif /* __LINUX_CONFIG_H__ */
