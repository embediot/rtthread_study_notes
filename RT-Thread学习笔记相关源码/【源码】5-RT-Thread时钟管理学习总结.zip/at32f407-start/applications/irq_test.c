#include <rthw.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "board.h"
#include "drv_gpio.h"
#include "irq_test.h"

#if (CURRENT_TEST == HW_INTERRUPT_TEST)

#define THREAD_PRIORITY      20
#define THREAD_STACK_SIZE    512
#define THREAD_TIMESLICE     5

static rt_uint32_t cnt;   //����һ��ȫ�ֱ���

//�̺߳������
void thread_entry(void *parameter)
{
    rt_uint32_t no;
    rt_uint32_t level;

    no = (rt_uint32_t) parameter;
	
    while (1)
    {
        level = rt_hw_interrupt_disable();    //�ر�ȫ���ж�
        cnt += no;
        rt_hw_interrupt_enable(level);     //��ȫ���ж�

        rt_kprintf("protect thread[%d]'s counter is %d\n", no, cnt);
        rt_thread_mdelay(no * 10);
    }
}

int hw_interrupt_test(void)
{
    rt_thread_t thread;

    thread = rt_thread_create("thread1", thread_entry, (void *)10,
                              THREAD_STACK_SIZE,
                              THREAD_PRIORITY, THREAD_TIMESLICE);
    if (thread != RT_NULL)
        rt_thread_startup(thread);

    thread = rt_thread_create("thread2", thread_entry, (void *)20,
                              THREAD_STACK_SIZE,
                              THREAD_PRIORITY, THREAD_TIMESLICE);
    if (thread != RT_NULL)
        rt_thread_startup(thread);

    return 0;
}


#elif (CURRENT_TEST == BUTTON_IRQ_TEST)
#define THREAD_PRIORITY      20
#define THREAD_STACK_SIZE    512
#define THREAD_TIMESLICE     5

/* defined the BUTTON pin: PC13 */
#define BUTTON_PIN    GET_PIN(A, 0)

ALIGN(RT_ALIGN_SIZE)
static char thread1_stack[1024];   
static struct rt_thread thread1;   
static struct rt_mailbox mb_btn_irq;    //����һ������
static char mb_pool[128];               //���������

static char mb_str1[] = "button press";               
static char mb_str2[] = "button up";

//�����жϴ�������
static void button_irq_handler(void)
{
		int button_value = 0;
	
		rt_kprintf(">>> button_irq_handler >>>\n");
	
		rt_thread_mdelay(20);
	
		button_value = rt_pin_read(BUTTON_PIN);
		
		if(button_value)
		{
				rt_mb_send(&mb_btn_irq,(rt_ubase_t)&mb_str1);
		}
		else
		{
				rt_mb_send(&mb_btn_irq,(rt_ubase_t)&mb_str2);
		}
}

//�߳�1�������
static void thread1_entry(void *parameter)
{
    char *str;

    while (1)
    {
        //rt_kprintf("thread1: try to recv a mail\n");

        if (rt_mb_recv(&mb_btn_irq, (rt_ubase_t *)&str, RT_WAITING_FOREVER) == RT_EOK)
        {            
            if (str == mb_str1)
						{
								rt_kprintf("button press,the string is %s \n",str);
						}		
						else
						{
								rt_kprintf("button up,the string is %s \n",str);
						}
                          
            rt_thread_mdelay(100);
        }
    }

    //rt_mb_detach(&mb_btn_irq);  //
}

int button_irq_test(void)
{
		rt_err_t result;
	
		//��ʼ������
    result = rt_mb_init(&mb_btn_irq,
                        "mb_btn",                   
                        &mb_pool[0],                
                        sizeof(mb_pool) / 4,        
                        RT_IPC_FLAG_FIFO);         
    if (result != RT_EOK)
    {
        rt_kprintf("init mailbox failed.\n");
        return -1;
    }

		//��ʼ�������ж�
		rt_pin_attach_irq(BUTTON_PIN,PIN_IRQ_MODE_RISING_FALLING,(void*)&button_irq_handler,NULL);
		rt_pin_irq_enable(BUTTON_PIN, PIN_IRQ_ENABLE);
		
		//��ʼ���߳�1
    rt_thread_init(&thread1,
                   "thread1",
                   thread1_entry,
                   RT_NULL,
                   &thread1_stack[0],
                   sizeof(thread1_stack),
                   THREAD_PRIORITY, THREAD_TIMESLICE);
    rt_thread_startup(&thread1);
									 
		return 0;
}
#else
#endif

