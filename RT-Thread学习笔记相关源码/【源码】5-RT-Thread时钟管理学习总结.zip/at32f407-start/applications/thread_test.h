#ifndef _THREAD_TEST_H_
#define _THREAD_TEST_H_


#define THREAD_TEST             0x01
#define TIMESLICE_TEST          0x02
#define SCHEDULER_HOOK_TEST     0x03

#define CURRENT_TEST            TIMESLICE_TEST


#if (CURRENT_TEST == THREAD_TEST)

extern void thread_test_init(void);

#elif (CURRENT_TEST == TIMESLICE_TEST)

extern void timeslice_test_init(void);

#elif (CURRENT_TEST == SCHEDULER_HOOK_TEST)

extern void scheduler_test_init(void);

#else 

#endif




#endif

